#include<iostream>
#include <string>
using namespace std;


const int MAX_STUDENTS = 100;



// Structure 
struct Student
 {
    int id;
    string name;
    char grade;
    int attendance;
    float marks;
};

// Array to store student records
Student students[MAX_STUDENTS];
int studentCount = 0;

// Function to check if a student ID already exists
bool isStudentIDExists(int id)
 {
    for (int i = 0; i < studentCount; i++) 
	{
        if (students[i].id == id)
		 {
            return true;
        }
    }
    return false;
}

// Function 
void addStudent()
 {
    if (studentCount >= MAX_STUDENTS)
	 {
        cout << "Student limit reached. Cannot add more students."<<endl;
        return;
    }

    Student newStudent;
    cout << "Enter Student ID: ";
    cin >> newStudent.id;

    // Check if the ID already exists
    if (isStudentIDExists(newStudent.id))
	 {
        cout << "Student with this ID already exists. Cannot add duplicate."<<endl;
        return;
    }

    cout << "Enter Student Name: ";
    cin >> newStudent.name;
    cout << "Enter Grade: ";
    cin >> newStudent.grade;
    cout << "Enter Attendance (in %): ";
    cin >> newStudent.attendance;

    newStudent.marks = 0; 

    students[studentCount++] = newStudent;
    cout << "Student added successfully!"<<endl;
}

// Function 
void displayStudents()
 {
    if (studentCount == 0)
	 {
        cout << "No students to display."<<endl;
        return;
    }

    cout << " Student Records:"<<endl;
    for (int i = 0; i < studentCount; i++)
	 {
        cout << "ID: " << students[i].id
             << ", Name: " << students[i].name
             << ", Grade: " << students[i].grade
             << ", Attendance: " << students[i].attendance << "%"
             << ", Marks: " << students[i].marks << " "<<endl;
    }
}

// Function 
void searchStudent()
 {
    int searchID;
    cout << "Enter Student ID to search: ";
    cin >> searchID;

    for (int i = 0; i < studentCount; i++) 
	{
        if (students[i].id == searchID) 
		{
            cout << "Student Found:"<<endl;
            cout << "ID: " << students[i].id
                 << ", Name: " << students[i].name
                 << ", Grade: " << students[i].grade
                 << ", Attendance: " << students[i].attendance << "%"
                 << ", Marks: " << students[i].marks << " "<<endl;
            return;
        }
    }
    cout << "Student with ID " << searchID << " not found."<<endl;
}


// Function 
void updateStudent() 
{
    int updateID;
    cout << "Enter Student ID to update: ";
    cin >> updateID;

    for (int i = 0; i < studentCount; i++) 
	{
        if (students[i].id == updateID)
		 {
            cout << "Enter New Name: ";
            cin.ignore();
            getline(cin, students[i].name);
            cout << "Enter New Grade: ";
            cin >> students[i].grade;
            cout << "Enter New Attendance (in %): ";
            cin >> students[i].attendance;

            cout << "Student record updated successfully!"<<endl;
            return;
        }
    }
    cout << "Student with ID " << updateID << " not found."<<endl;
}

// Function 
void deleteStudent()
 {
    int deleteID;
    cout << "Enter Student ID to delete: ";
    cin >> deleteID;

    for (int i = 0; i < studentCount; i++)
	 {
        if (students[i].id == deleteID) 
		{
            for (int j = i; j < studentCount - 1; j++) 
			{
                students[j] = students[j + 1];
            }
            studentCount--;
            cout << "Student record deleted successfully!"<<endl;
            return;
        }
    }
    cout << "Student with ID " << deleteID << " not found."<<endl;
}

// Function 
void addMarks()
 {
    int studentID;
    cout << "Enter Student ID to add marks: ";
    
    cin >> studentID;

    for (int i = 0; i < studentCount; i++) 
	{
        if (students[i].id == studentID) 
		{
            cout << "Enter Marks to Add: ";
            cin >> students[i].marks;
            cout << "Marks updated successfully for Student ID: " << studentID << " "<<endl;
            return;
        }
    }
    cout << "Student with ID " << studentID << " not found."<<endl;
}

// Function 

bool validatePassword() {
    string correctPassword = "admin123";  
    
    
    
    string enteredPassword;

    cout << "Enter the password to access the system: ";
    
    cin >> enteredPassword;

    if (enteredPassword == correctPassword)
	 {
        cout << "Access Granted."<<endl;
        return true;
    } 
	else
	 {
        cout << "Access Denied. Incorrect Password."<<endl;
        return false;
    }
}


int main() 
{
    if (!validatePassword()) 
	{
        return 0;
    }

    int choice;
    cout << "**************************************************"<<endl;
    cout << "          ********** WELCOME **********            "<<endl;
    cout << "************************************************** "<<endl;

    do {
        cout << "=================================================="<<endl;
        
        cout << "          *** CHOOSE AN OPTION PLEASE ***         "<<endl;
        cout << "=================================================="<<endl;
        cout << "|                                                |"<<endl;
        cout << "|     Student Record Management System           |"<<endl;
        cout << "|                                                |"<<endl;
        cout << "|  1. Add Student                                |"<<endl;
        cout << "|  2. Display All Students                       |"<<endl;
        cout << "|  3. Search Student by ID                       |"<<endl;
        cout << "|  4. Update Student Details                     |"<<endl;
        cout << "|  5. Delete Student                             |"<<endl;
        cout << "|  6. Add Marks to Student                       |"<<endl;
        cout << "|  7. Exit                                       |"<<endl;
        cout << "|                                                |"<<endl;
        cout << "|                                                |"<<endl;
        
        cout << "=================================================="<<endl;
        cout << "         Enter your choice: ";
        
        
        cin >> choice;

        switch (choice) 
		
		{
            case 1:
            	
                system("color D7");
                addStudent();
                break;
                
            case 2:
            	
                system("color E0");
                displayStudents();
                break;
                
            case 3:
            	
            	
                system("color E8");
                searchStudent();
                break;
                
                
            case 4:
            	
            	
                system("color F9");
                updateStudent();
                break;
                
                
            case 5:
            	
                system("color F8");
                deleteStudent();
                break;
            
            case 6:
            	
                system("color F2");
                addMarks();
                break;
            case 7:
            	
                cout << "Exiting the system. Goodbye!"<<endl;
                break;
            default:
                cout << "Invalid choice. Please try again."<<endl;
        }
        
    } 
	
	while (choice != 7);

    return 0;
    
}

